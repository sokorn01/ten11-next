import { serviceApiFormData } from "../../shared/hooks/seviceApi";
import {
  FETCH_MENU_REQUEST,
  FETCH_MENU_SUCCESS,
  FETCH_MENU_FAILURE,
} from "../types";

export const fetchMenu = () => {
  const service = serviceApiFormData();
  return (dispatch) => {
    dispatch(fetchMenuRequest());
    service
      .post("MenuApp/getMenu")
      .then((response) => {
        dispatch(fetchMenuSuccess(response.data.menu));
      })
      .catch((error) => {
        dispatch(fetchMenuFailure(error.message));
      });
  };
};

export const fetchMenuRequest = () => {
  return {
    type: FETCH_MENU_REQUEST,
  };
};

export const fetchMenuSuccess = (param) => {
  return {
    type: FETCH_MENU_SUCCESS,
    payload: param,
  };
};

export const fetchMenuFailure = (error) => {
  return {
    type: FETCH_MENU_FAILURE,
    payload: error,
  };
};

### Build in development
> npm run dev

### Build in production
> npm run build
> npm run start

### Install svn
> brew install svn

### install svn in visual studio code
> go to exstention svn

### Checkout project
> svn checkout url

### configure redux with project next.js
1. instatll package
    > npm i --save redux react-redux next-redux-wrapper redux-thunk

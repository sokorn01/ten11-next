import React, { useEffect, useState } from "react";
import { useRouter } from "next/router";
import "../productList.css";
import Layout from "../../components/layouts/Layout";
import Container from "../../components/Containers/Container";
import "antd/dist/antd.css";
import ProductItem from "../../components/Products/ProductItem";
import useSticky from "../../shared/hooks/useSticky";
import ProductListLoading from "../../components/Loading/ProductListLoading";
import ListSideBarMenu from "../../components/Products/ListSideBarMenu";
import InfiniteScroll from "react-infinite-scroll-component";
import { FiRefreshCw } from "react-icons/fi";
import { serviceApiFormData } from "../../shared/hooks/seviceApi";

const ProductList = (props) => {
  const router = useRouter();
  const { page, id, slug } = router.query;
  const { hideNav } = useSticky;
  const [hasMore, setHasMore] = useState(true);
  const [listProduct, setListProduct] = useState([]);

  useEffect(() => {
    if (props.product !== undefined && props.product.list !== undefined) {
      if (Number(page) === 1) {
        setListProduct(props.product.list);
        localStorage.setItem("totalproduct", props.product.total_record);
      } else if (Number(page) > 1) {
        setListProduct([...listProduct, ...props.product.list]);
      }
    }
  }, [props.product]);

  function onChange(e) {
    console.log(`checked = ${e.target.checked}`);
  }

  const loadItems = () => {
    const totalProduct = localStorage.getItem("totalproduct");
    if (listProduct.length > 0)
      if (listProduct.length < Number(totalProduct)) {
        setHasMore(true);
        router.push(`/product/${slug}/?id=${id}&&page=${Number(page) + 1}`);
      } else {
        setHasMore(false);
      }
  };

  const refresh = () => {};
  const loader = (
    <div className="load-more">
      <div className="load-more-block" onClick={props.onClick}>
        <FiRefreshCw
          className={`${hasMore ? "load-more-icon" : "no-load-more"}`}
        />
        <span>Load more...</span>
      </div>
    </div>
  );

  // if (props.isLoading) return <ProductListLoading />;
  if (router.isFallback) {
    return <ProductListLoading />;
  }
  return (
    <React.Fragment>
      <Layout
        menu={props.menu.menu}
      >
        <Container>
          <div className="row">
            <ListSideBarMenu
              // mainCategory={slug[0]}
              // paramsId={paramsId}
              category_name={slug[0]}
              hideNav={hideNav}
              onChange={onChange}
            />
            <div className="main">
              <InfiniteScroll
                className="rowChild"
                dataLength={listProduct.length || 0}
                next={loadItems}
                hasMore={hasMore}
                loader={loader}
                refreshFunction={refresh}
                pullDownToRefresh
                pullDownToRefreshThreshold={50}
              >
                {listProduct.map((item, index) => (
                  <ProductItem key={index} {...item} />
                ))}
              </InfiniteScroll>
            </div>
          </div>
        </Container>
      </Layout>
    </React.Fragment>
  );
};

// export async function getStaticPaths() {
//   const api = serviceApiFormData();
//   const res = await api.post("MenuApp/getMenu");
//   const paths = res.data.menu.map((a) => {
//     return {
//       params: { id: a.category_id.toString() },
//     };
//   });
//   return {
//     fallback: true,
//     paths,
//   };
// }

// export async function getStaticProps(ctx) {
//   console.log(ctx);
//   const api = serviceApiFormData();
//   const res = await api.post("MenuApp/getMenu");
//   const menu = res.data;
//   return {
//     props: {
//       menu,
//     },
//   };
// }

export async function getServerSideProps(context) {
  const { page, id } = context.query;
  try {
    const api = serviceApiFormData();
    const res = await api.post("MenuApp/getMenu");
    const menu = res.data;
    const data = {
      page: page,
      category_id: id,
    };
    const productList = await api.post("ListProduct/getProductList", data);
    const product = productList.data;
    return {
      props: {
        product,
        menu,
      },
    };
  } catch {
    return {
      props: {
        product: {},
        menu: {},
      },
    };
  }
}

export default ProductList;
